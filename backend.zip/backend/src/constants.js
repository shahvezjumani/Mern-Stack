export const DB_NAME = "Blog";
